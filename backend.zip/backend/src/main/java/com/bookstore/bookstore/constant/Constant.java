package com.bookstore.bookstore.constant;

public class Constant {
}
