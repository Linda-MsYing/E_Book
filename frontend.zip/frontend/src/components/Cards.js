import React from 'react';
import '../css/Cards.css';
import CardItem from './CardItem';
import SearchBox from './SearchBox';
// import Books from './Books';
// import Pagination from './Pagination'
import {BookCarousel} from "../components/BookCarousel";
import axios from 'axios';
import { useParams } from "react-router-dom";
import { useState, useEffect } from "react";


function Cards() {

    let userlist = []
    if (window.localStorage.userlist) userlist = JSON.parse(window.localStorage.userlist);
    let value = userlist[userlist.length-1];

    axios({
        method: 'GET',
        url: 'http://localhost:9092/getBooks',
        // params: {
        //     username: value.username,
        //     password: value.password,
        // }
    }).then(response => {
        console.log(response)
        // alert("get data success");
    }).catch(error => {
        console.log(error)
        alert("fail to get data");
    })

    let { keyword } = useParams();
    const [books, setBooks] = useState(null);
    useEffect(function effectFunction() {
        async function fetchBooks() {
            const res = await fetch("http://localhost:9092/getBooks");
            if (!res.ok) throw res;
            const json = await res.json();
            if (json.error) throw res;
            setBooks(json);
        }
        fetchBooks();
    }, []);
    var cards;
    console.log(books);
    if (typeof keyword == "undefined")
        cards =
            books == null
                ? () => <div />
                : Object.values(books).map((i) => (
                    <CardItem
                        id={i.id}
                        text={i.bookname}
                        author={i.author}
                        price={i.price}
                        ISBN ={i.isbn}
                        src={i.image}
                        // inventory = {i.inventory}
                        // label={i.type}
                        path= '/Book'
                    />
                ));
    else
        cards =
            books == null
                ? () => <div />
                : Object.values(books)
                    .filter((i) => Object.values(i).join().includes(keyword))
                    .map((i) => (
                        <CardItem
                            id={i.id}
                            text={i.bookname}
                            author={i.author}
                            price={i.price}
                            ISBN ={i.isbn}
                            src={i.image}
                            inventory = {i.inventory}
                            label={i.type}
                            path= '/Book'
                        />
                    ));
  return (
    <div className='cards'>
      <h1>OUR COMMAND!</h1>
      <SearchBox />
      <BookCarousel />

      <div className='cards__container'>
        <div className='cards__wrapper'>
          <ul className='cards__items'>
            {cards}
          </ul>

        </div>
      </div>
    </div>
  );
}

export default Cards;
