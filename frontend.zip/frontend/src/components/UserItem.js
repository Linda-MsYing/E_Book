import React from 'react';
import '../App.css';
import '../css/Admin.css';
// import Divider from '@material-ui/core/Divider';
import { Link } from 'react-router-dom';
import SearchBox from '../components/SearchBox';
import { Button, Input, Select, Space, Radio,Image, Upload } from 'antd';
import axios from 'axios';

let userlist = []
if (window.localStorage.userlist) userlist = JSON.parse(window.localStorage.userlist);
let value = userlist[userlist.length-1];
function DeleteUser(id) {
    axios({
        method: 'GET',
        url: 'http://localhost:9092/editUser',
        params: {
            username: value.username,
            password: value.password,
            userid: id,
            changedstate: 'Abnormal',
        }
    }).then(response => {
        console.log(response)
        alert("Delete user successfully");
    }).catch(error => {
        console.log(error)
        alert("fail to delete user");
    })
    window.location.href="http://localhost:3000/Administrator";
}
function AddUser(id) {
    axios({
        method: 'GET',
        url: 'http://localhost:9092/editUser',
        params: {
            username: value.username,
            password: value.password,
            userid: id,
            changedstate: 'Normal',
        }
    }).then(response => {
        console.log(response)
        alert("Add user successfully");
    }).catch(error => {
        console.log(error)
        alert("fail to add user");
    })
    window.location.href="http://localhost:3000/Administrator";
}
function UserItem(props) {

    return (
        <div>
            <div className="title-total">
                <h3>User:  {props.id} </h3>
                <h4>name:  {props.name}</h4>
                <h4>password:  {props.password}</h4>
                <h4>state:  {props.state}</h4>
                <div className="actions">
                    <Button
                        onClick={()=>DeleteUser(props.id)}
                    >Forbid User
                    </Button>
                    <Button
                        onClick={()=>AddUser(props.id)}
                    >Permit User
                    </Button>
                </div>
            </div>
        </div>



    );
}

export default UserItem;

