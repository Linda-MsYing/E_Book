import React, {useEffect, useState} from 'react';
import ReactDOM from 'react-dom';
import '../css/Admin.css';
import axios from "axios";
import {useParams} from "react-router-dom";
import OrderItem from "../components/OrderItem";
import SearchBox from "../components/SearchBox";
import UserItem from '../components/UserItem';
const data = [];
const headers = ["User Id", "name", "nick name", "tel", "type (0: forbidden  1: Customer 2: Administrator)"];

// function Administrator()
function Administrator() {
    let userlist = []
    if (window.localStorage.userlist) userlist = JSON.parse(window.localStorage.userlist);
    let value = userlist[userlist.length-1];
    axios({
        method: 'GET',
        url: 'http://localhost:9092/getUsers',
        params: {
            username: value.username,
            password: value.password,
        }
    }).then(response => {
        console.log(response)

    }).catch(error => {
        console.log(error)
        alert("You are not ADMIN! Fail to get Users!");
    })

    let { keyword } = useParams();
    const [books, setUsers] = useState(null);
    useEffect(function effectFunction() {
        async function fetchUsers() {
            const res = await fetch("http://localhost:9092/getUsers?username="+value.username+"&password="+value.password);
            if (!res.ok) throw res;
            const json = await res.json();
            if (json.error) throw res;
            setUsers(json);
        }
        fetchUsers();
    }, []);
    var users;
    console.log(users);
    if (typeof keyword == "undefined")
        users =
            books == null
                ? () => <div />
                : Object.values(books).map((i) => (
                    <UserItem
                        id={i.id}
                        name={i.username}
                        password={i.password}
                        state={i.state}
                    />
                ));
    else
        users =
            books == null
                ? () => <div />
                : Object.values(books)
                    .filter((i) => Object.values(i).join().includes(keyword))
                    .map((i) => (
                        <UserItem
                            id={i.id}
                            name={i.name}
                            password={i.password}
                        />
                    ));
    if(window.localStorage.userlist==null){
        alert("请先登录！");
        window.location.href="http://localhost:3000";
        return(
            <div className="card">
            </div>
        ); ;
    };
    return (
        <div className="card">
            <h1>Admin User</h1>
            {/*<SearchBox />*/}

            {users}

        </div>
    );
}

export default Administrator;
