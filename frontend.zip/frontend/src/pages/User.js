import React, { useState } from 'react';
import {UploadOutlined, UserOutlined} from '@ant-design/icons';
import { Button, Input, Select, Space, Radio,Image, Upload } from 'antd';
import '../css/Cart.css';
import axios from "axios";

const { TextArea } = Input;
const options = [
    {
        value: 'zhejiang',
        label: 'Zhejiang',
    },
    {
        value: 'Shanghai',
        label: 'Shanghai',
    },
];

function upload(){
    alert("确定上传您的书籍商品？");
    window.location.reload();
    alert("上传成功，您的书籍正在审核中！");
}
function User() {
    var userlist = window.localStorage.userlist;
    if(userlist==null){
        window.location.href="http://localhost:3000";
        alert("请先登录！");
        return;
    }

    return (
        <>
            <h1><b>My Book Creation</b></h1>
            <h1><b>Come to upload your own work!</b></h1>
            <div className='cards__container'>
            <Space direction="vertical" size="middle">
                <h3><b>Book Picture</b></h3>
                <Space.Compact>
                <Image height={400} width={350} src='images/userphoto2.png' />
                </Space.Compact>
                <Space.Compact>
                <Upload>
                    <Button>
                        <UploadOutlined /> Click to Upload
                    </Button>
                </Upload>
                </Space.Compact>
                <h3><b>Author Name</b></h3>
                <Space.Compact>
                    <Input style={{ width: 350 }} defaultValue="Linda" />
                </Space.Compact>
                {/*<h3><b>Phone Numble</b></h3>*/}
                {/*<Space.Compact>*/}
                {/*    <Input style={{ width: 100 }} defaultValue="+86" />*/}
                {/*    <Input style={{ width: 250 }} defaultValue="15877480976" />*/}
                {/*</Space.Compact>*/}

                <h3><b>Price</b></h3>
                <Space.Compact>
                    <Input style={{ width: 250 }} defaultValue="50" />
                    <Input style={{ width: 100 }} defaultValue="RMB" />
                </Space.Compact>

                <h3><b>Shipping Address</b></h3>
                <Space.Compact>
                    <Select style={{ width: 100 }} defaultValue="Shanghai" options={options} />
                    <Input style={{ width: 250 }} defaultValue="Minhang" />
                </Space.Compact>
                <h3><b>Types</b></h3>
                <Space.Compact>
                    <Radio.Group>
                        <Space direction="vertical">
                            <Radio value={1}>Novel</Radio>
                            <Radio value={2}>Prose</Radio>
                            <Radio value={3}>Cartoon</Radio>
                            <Radio value={4}>Others</Radio>
                        </Space>
                    </Radio.Group>
                </Space.Compact>
            </Space>
            </div>

            <div className='cards__container'>
            <h3><b>Description</b></h3>
            <TextArea style={{ width: 700 }} rows={5} defaultValue="This is a very good book"  />
            </div>
            <div className='cards__container'>
            <Button
                style={{ width: 350 }}
                // style={{ marginRight: -20 }}
                size="large"
                type="Primary"
                onClick={upload}
            >
                Upload »
            </Button>
            <Button
                style={{ width: 350 }}
                // style={{ marginRight: -20 }}
                size="large"
                type="Primary"
            >
                Cancel »
            </Button>
            </div>
        </>


    );
}

export default User;