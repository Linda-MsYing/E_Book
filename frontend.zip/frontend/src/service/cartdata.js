// window.localStorage.booklist= [
//     { id: 1, cover:'images/harryCoverSingle.jpeg',name: "Harry Poter", datas: 'J·K·Rowling', price: 50, numbers: 1 },
//     { id: 2, cover: 'images/3bodyCoverSingle.jpeg',name: "Three Body", datas: 'CiXing Liu', price: 45, numbers: 1 },
//     { id: 3, cover: 'images/APromiseCoverSingle.jpg',name: "Pride and Prejudice", datas: 'Jane Austen', price: 70, numbers: 2 },
//     { id: 4, cover: 'images/JobsCover.jpeg',name: "Steve Jobs", datas: 'Walter Isaacson', price: 115, numbers: 1 },
// ]